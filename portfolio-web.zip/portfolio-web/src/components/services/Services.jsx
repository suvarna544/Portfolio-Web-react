import React from 'react'
import {Container, Row, Col} from 'reactstrap'
import "remixicon/fonts/remixicon.css";
import "./services.css"
import "bootstrap/dist/css/bootstrap.min.css";

const servicesData=[
{

    icon:'ri-code-line',
    title:' Web Design',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi error dolorem doloribus, nobis vitae et nisi dicta rerum perspiciatis fugit.'
},

{

    icon:'ri-code-s-slash-line',
    title:' Web Development',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi error dolorem doloribus, nobis vitae et nisi dicta rerum perspiciatis fugit.'
},

{

    icon:'ri-qr-code-line',
    title:' App Development',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi error dolorem doloribus, nobis vitae et nisi dicta rerum perspiciatis fugit.'
},

{

    icon:'ri-gallery-line',
    title:' UI / UX',
    desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi error dolorem doloribus, nobis vitae et nisi dicta rerum perspiciatis fugit.'
}



]

const Services = () => {
  return (
    <section id="services">
      <Container>
        <Row>
            <Col lg="12" className='services_top mb-5'>
                <h6>Features</h6>
                <h2>What Services I Provide</h2>
            </Col>


          {
            servicesData.map((item,index)=>(
            <Col lg="5" md="4" sm="4" key={index} className='mb-4'>

        
            <div className="single_service">
               <span className="service_icon">
              <i class={item.icon}></i>
              </span>
   
              <h2>{item.title}</h2>
            <p>{item.desc}</p>
            </div>
             </Col>
            
            ))
          }

      
       </Row>
      </Container>
    </section>
    
  )
}

export default Services
