import React from 'react'
import './education.css'
import "bootstrap/dist/css/bootstrap.min.css";

const Education = () => {
  return <table className='table'>
    <thead className='thead'>
        <tr>
            <th>Degree</th>
            <th> Department</th>
            <th>Institute</th>
            <th>Years</th>
        </tr>
    </thead>
     <tbody>
      <tr>
        <td>B.Tech</td>
        <td>Computer Science Engineering</td>
        <td>A.G Patil Institute Of Technology, Solapur</td>
        <td>2018-2022</td>
        </tr>   
        <tr>
        <td>Diploma</td>
        <td>Computer Engineering</td>
        <td>A.G Patil Polytechnic Institute Of Technology, Solapur</td>
        <td>2016-2018</td>
        </tr>     
        <tr>
        <td>SSC</td>
        <td>General</td>
        <td>Jagruti Vidya Mandir Neharunagar, Solapur</td>
        <td>2015-2016</td>
        </tr>       
        </tbody>  
 
  </table>
}

export default Education
