import React, {useRef, useEffect}from 'react'
import './hero-section.css'
import "bootstrap/dist/css/bootstrap.min.css";
import { Container,Row,Col } from 'reactstrap'
import suvarnapic from "../../assests/images/suvarnapic.jpg"

// import {init} from 'ityped';
import Typed from "typed.js";

const HeroSection = () => {
    const textRef = useRef(null);

    useEffect(() => {
      const typed = new Typed(textRef.current, {
        strings: ['Suvarna Pawar', 'a FrontEnd Developer'], // Strings to display
        // Speed settings, try diffrent values untill you get good results
        startDelay: 300,
        typeSpeed: 100,
        loop: true,
        showCursor: true,
        backSpeed: 100,
        backDelay: 100
      });
  
      // Destropying
      return () => {
        typed.destroy();
      };
    }, []);
  return( 
  <section className='hero_section' id="home" >
   <Container>
    <Row>
        <Col lg="6" md="6">
            <div className='hero_content'>
                <p className='mb-3'>Welcome to my world</p>
                <h5 className='mb-4'>Hii</h5>
                
                <h2 className='hero_title mb-4'>  
                    I'm <span ref={textRef}> </span>
                    </h2>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quidem ex voluptate fugiat ea accusantium amet possimus quis debitis sit eligendi! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus, accusamus!</p>

                <div className=" mt-4 hero_btns d-flex align-items-center gap-4">
                <button className='btn hire_btn'>Hire Me</button>
               <button className="btn contact_btn">Contact</button>
               </div>
            </div>
        </Col>
        <Col lg="6" md='6'>
            <div className='hero_img'>
                <img src={suvarnapic} alt="" className='w-100'/>
            </div>
        </Col>
    </Row>
   </Container>
  </section>
  )
}

export default HeroSection
