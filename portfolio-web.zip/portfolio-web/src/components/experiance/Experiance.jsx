import React from 'react'
import './experiance.css'
import {Container,Row, Col} from 'reactstrap'
import "bootstrap/dist/css/bootstrap.min.css";

const developmentExperianceData=[
    {
        year:'2022 - 2022',
        title:'Intern',
        desc: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nisi accusamus a doloribus illum consectetur hic, eaque vero. Eos, culpa officia.'
    },
    {
        year:'2022 - Present',
        title:'Software Engineer',
        desc: 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nisi accusamus a doloribus illum consectetur hic, eaque vero. Eos, culpa officia.'
    }

]

const Experiance = () => {
  return (
    <section id='experiance'>
        <Container>
            <Row>
                <Col lg="12" className='mb-5'>
             <h2>Experiance</h2>

             </Col>
               <Col lg="6" md="6">
                <div className="single_experiance-container">
                    {
                        developmentExperianceData.map((item,index)=> (

                            <div className="single_experiance" key={index}>
                            <span className='experiance_icon'>
                                <i class="ri-briefcase-line"></i> </span>
                                <h6>{item.year}</h6>
                            
                                <h5>{item.title}</h5>
                                <p>{item.desc}</p>
                           
                          </div>
                          )  )
                    }
                </div>
               </Col>

               <Col lg="6" md="6">
                <div className="single_experiance-container">
                    {
                        developmentExperianceData.map((item,index)=> (

                            <div className="single_experiance" key={index}>
                            <span className='experiance_icon'>
                                <i class="ri-briefcase-line"></i> </span>
                                <h6>{item.year}</h6>
                            
                                <h5>{item.title}</h5>
                                <p>{item.desc}</p>
                           
                          </div>
                          )  )
                    }
                </div>
               </Col>




            </Row>
        </Container>
    </section>
   
  )
}

export default Experiance
